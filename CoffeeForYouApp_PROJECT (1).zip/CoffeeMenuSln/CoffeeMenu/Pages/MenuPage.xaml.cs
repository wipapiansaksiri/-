﻿using CoffeeMenu.Models;
using CoffeeMenu.Services;
namespace CoffeeMenu.Pages;

public partial class MenuPage : ContentPage
{
    Services.MenuService gen = new Services.MenuService();
    public MenuPage()
    {
        InitializeComponent();
        this.BindingContext = gen;
        App.IsAddNewRecipt = false;
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        gen.Generate();
    }

    private async void TapGestureRecognizer_Tapped(object sender, TappedEventArgs e)
    {
        // ดึงข้อมูลเมนูที่ถูกเลือก
        var selectedMenu = (sender as Image)?.BindingContext as Note;

        if (selectedMenu != null)
        {
            // เปิดหน้า Details และส่งข้อมูลเมนูที่ถูกเลือกไปด้วย
            await Navigation.PushAsync(new Details());
        }
    }
}