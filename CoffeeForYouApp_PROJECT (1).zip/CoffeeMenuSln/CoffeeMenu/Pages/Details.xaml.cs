﻿using CoffeeMenu.Models;


namespace CoffeeMenu.Pages
{
    public partial class Details : ContentPage
    {

        Services.MenuService gen = new Services.MenuService();

        public Details()
        {
            InitializeComponent();
            gen.Generate();
            this.BindingContext = gen;
        }

    }


}
