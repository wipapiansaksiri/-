namespace CoffeeMenu.Pages;

public partial class loginPage : ContentPage
{
	public loginPage()
	{
		InitializeComponent();
    }

    void btnLogin_Clicked(System.Object sender, System.EventArgs e)
    {
        Application.Current.MainPage = new AppShell();

    }
}