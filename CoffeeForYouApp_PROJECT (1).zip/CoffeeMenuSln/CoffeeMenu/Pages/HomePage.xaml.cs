﻿using CoffeeMenu.Models;
namespace CoffeeMenu.Pages;

public partial class HomePage : ContentPage
{
    Services.MenuService gen = new Services.MenuService();
    public HomePage()
	{
		InitializeComponent();
        gen.Generate();
        this.BindingContext = gen;
        App.IsAddNewRecipt = false;
    }

    protected async override void OnAppearing()
    {
        base.OnAppearing();
        if(App.IsAddNewRecipt ==true)
        {
            await Shell.Current.GoToAsync("xMainBar/xMenuPage");
        }
    }

    private async void ImageButton_Clicked_1(object sender, EventArgs e)
    {

        await Navigation.PushAsync(new MenuRecipePage
        {
            BindingContext = new Models.Note()
        });
    }
    private async void Image_Tapped(object sender, EventArgs e)
    {
        // ดึงข้อมูลเมนูที่ถูกเลือกจาก BindingContext ของรูปภาพ
        var selectedMenu = (sender as Image)?.BindingContext as Note;

        if (selectedMenu != null)
        {
            // เปิดหน้า Details และส่งข้อมูลเมนูที่ถูกเลือกไปด้วย
            await Navigation.PushAsync(new Details());
        }
    }
}
