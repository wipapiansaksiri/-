﻿using System;
using System.Collections.ObjectModel;
using System.Windows.Input;
namespace CoffeeMenu.Pages;

public partial class AddRecipt : ContentPage
{
    public ObservableCollection<Models.Note> Notes { get; set; }
    public ICommand DeleteNote { get; set; }
    public ICommand EditNote { get; set; }
    public AddRecipt()
	{
		InitializeComponent();
        
        DeleteNote = new Command<Models.Note>(DeleteCommand);
        EditNote = new Command<Models.Note>(EditCommand);
        Notes = new ObservableCollection<Models.Note>();
        this.BindingContext = this;
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        Notes.Clear();
        LoadNoteFromSQLite();
    }

   
    private async void LoadNoteFromSQLite()
    {
        var notedb = await App.Database.GetNotesAsync();
        foreach (var rowx in notedb)
            Notes.Add((Models.Note)rowx);
    }

    async void ToolbarItem_Clicked(System.Object sender, System.EventArgs e)
    {
        await Navigation.PushAsync(new MenuRecipePage(new Models.Note())

        {
            BindingContext = new Models.Note()
        }
        );
    }

    void btnShowAll_Clicked(System.Object sender, System.EventArgs e)
    {
        Notes.Clear();
        LoadNoteFromSQLite();
    }

    async void DeleteCommand(Models.Note delNote)
    {
        if (delNote != null)
        {
            bool answer = await
                DisplayAlert("ยืนยันการลบ ?",
                $"คุณต้องการลบ {delNote.Topic} ใช่หรือไม่", "ยืนยันลบ", "ไม่ลบ");

            if (answer == true)
            {
                await App.Database.DeleteNoteAsync(delNote);
                Notes.Remove(delNote);
            }
        }
    }

    async void EditCommand(Models.Note note)
    {
        if (note != null)
        {
            await Navigation.PushAsync(new MenuRecipePage
            {
                BindingContext = note
            });
        }
    }
}