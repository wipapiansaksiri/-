using CoffeeMenu.Services;
using System.IO;
using CoffeeMenu.Models;
using CoffeeMenu.Data;
namespace CoffeeMenu.Pages;

public partial class MenuRecipePage : ContentPage
{
    private NoteDatabase _noteDatabase;
    public MenuRecipePage()
    {
        InitializeComponent();
        var noteDatabase = new NoteDatabase();
    }
    public MenuRecipePage(Models.Note selectedMenu)
    {
        InitializeComponent();
       
    }

    string imagepath = string.Empty;

    async void btnSave_Clicked(System.Object sender, System.EventArgs e)
    {
        Models.Note note = (Models.Note)BindingContext;
        note.ImageUrl = imagepath;

        await App.Database.SaveNoteAsync(note);
        App.IsAddNewRecipt = true;
        await Navigation.PopAsync();

        var A = await App.Database.GetNoteAsync();
        foreach( var item in A) { 
        
        
                }
    }

    async void btnDelete_Clicked(System.Object sender, System.EventArgs e)
    {
        Models.Note note = (Models.Note)BindingContext;
        await App.Database.DeleteNoteAsync(note);
        await Navigation.PopAsync();
    }

    async void choose_Clicked(object sender, EventArgs e)
    {
        var pickResult = await FilePicker.PickAsync(new PickOptions
        {
            FileTypes = FilePickerFileType.Images,
            PickerTitle = "Pick an image"
        });
        if (pickResult != null)
        {
            var stream = await pickResult.OpenReadAsync();
            imagepath = Path.Combine(FileSystem.Current.AppDataDirectory, Guid.NewGuid().ToString() + ".png");
            byte[] data = StreamToByteArray(stream);
            await SaveImage(imagepath, data);
            resultImage.Source = ImageSource.FromFile(imagepath);


            // Save To Device
        }
    }

    public byte[] StreamToByteArray(Stream input)
    {
        using (MemoryStream ms = new MemoryStream())
        {
            input.CopyTo(ms);
            return ms.ToArray();
        }
    }
    public async Task SaveImage(string filePath, byte[] imageBytes)
    {
        using (var stream = new FileStream(filePath, FileMode.Create))
        {
            await stream.WriteAsync(imageBytes, 0, imageBytes.Length);
        }
    }
}