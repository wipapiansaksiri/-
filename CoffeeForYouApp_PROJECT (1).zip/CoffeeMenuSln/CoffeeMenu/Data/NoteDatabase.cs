﻿using SQLite;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using CoffeeMenu.Models;
using CoffeeMeun;

namespace CoffeeMenu.Data
{
    public class NoteDatabase
    {
        SQLiteAsyncConnection _database;
        async Task Init()
        {
            if (_database is not null)
                return;

            _database = new SQLiteAsyncConnection(Constants.DatabasePath, Constants.flags);
            await _database.CreateTableAsync<Note>(); // Sheet Note
            await _database.CreateTableAsync<Note>(); // Sheet Menu
        }
        public async Task<List<Note>> GetNotesAsync()
        {
            await Init();
            return await _database.Table<Note>().ToListAsync();
        }

        public async Task<List<Note>> GetMenusAsync()
        {
            await Init();
            return await _database.Table<Note>().ToListAsync();
        }

        public async Task<List<Note>> GetNotesAsync(string pKeyword)
        {
            await Init();
            return await _database
                .Table<Note>()
                .Where(x => x.Text.Contains(pKeyword)
                || x.Topic.Contains(pKeyword))
                .ToListAsync();
        }

        public async Task<Note> GetNoteAsync(int pNoteId)
        {
            await Init();
            return await _database
                .Table<Note>()
                .Where(x => x.ID == pNoteId)
                .FirstOrDefaultAsync();
        }

        public  Task<List<Note>> GetNoteAsync()
        {
            return _database.Table<Note>()
                .ToListAsync();
        }


        public async Task<int> SaveNoteAsync(Note note)
        {
            await Init();
            if (note.ID != 0)
            {
                return await _database.UpdateAsync(note);
            }
            else
            {
                return await _database.InsertAsync(note);
            }
        }

        public async Task<int> DeleteNoteAsync(Note pDelNote)
        {
            await Init();
            return await _database.DeleteAsync(pDelNote);
        }


    }
}