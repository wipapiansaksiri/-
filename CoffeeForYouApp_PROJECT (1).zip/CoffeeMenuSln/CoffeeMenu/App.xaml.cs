﻿using CoffeeMenu.Pages;
using Microsoft.Maui.Controls;
using System.IO;
namespace CoffeeMenu
{
    public partial class App : Application
    {
        public static bool IsAddNewRecipt { get; set; }
        public static Data.NoteDatabase Database { get; private set; }
        public App()
        {
            InitializeComponent();


            Routing.RegisterRoute("xMainBar/xMenuPage", typeof(MenuPage));

            Database = new Data.NoteDatabase();
            MainPage = new Pages.loginPage();

        }
    }
}
