﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SQLite;
using System.Threading.Tasks;

namespace CoffeeMenu.Models
{
    public class Note
    {
        [PrimaryKey, AutoIncrement]
        public int ID { get; set; }
        public string Topic { get; set; }
        public string Text { get; set; }
        public string Name { get; set; }
        public string Details { get; set; }
        public string ImageUrl { get; set; }
        public string Unit { get; set; }
        public string Color { get; set; }

        internal static async Task LoadMenusAsync()
        {
            throw new NotImplementedException();
        }
    }

}